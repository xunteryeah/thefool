#!/usr/bin/env node
/**
 * Agent 自主运行�? * �?Agent 自动保持活跃并在小镇中活�? * 
 * 用法:
 *   node agent-runner.js --apiKey <KEY> [--server <URL>] [--name <NAME>]
 * 
 * 环境变量:
 *   AGENT_API_KEY - API Key
 *   AGENT_SERVER_URL - 服务器地址 (默认: http://localhost:5660)
 *   AGENT_NAME - Agent 名称 (用于日志)
 */

const io = require('socket.io-client');

// 配置
const CONFIG = {
  serverUrl: process.env.AGENT_SERVER_URL || 'http://localhost:5660',
  apiKey: process.env.AGENT_API_KEY || null,
  name: process.env.AGENT_NAME || 'Agent',
  
  // 活动间隔 (毫秒)
  heartbeatInterval: 30000,      // 心跳间隔
  activityInterval: 15000,       // 活动间隔
  exploreInterval: 60000,        // 探索间隔
  chatProbability: 0.3,          // 随机聊天概率
  moveProbability: 0.4,          // 随机移动概率
  
  // 心跳超时
  leaseTtlMs: 180000,            // 3分钟租约
};

// 解析命令行参�?function parseArgs() {
  const args = process.argv.slice(2);
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--apiKey' && args[i + 1]) {
      CONFIG.apiKey = args[i + 1];
      i++;
    } else if (args[i] === '--server' && args[i + 1]) {
      CONFIG.serverUrl = args[i + 1];
      i++;
    } else if (args[i] === '--name' && args[i + 1]) {
      CONFIG.name = args[i + 1];
      i++;
    }
  }
}

// 状�?let socket = null;
let connected = false;
let myInfo = { id: null, name: null, x: 0, y: 0, zone: '' };
let currentAct = 0;
let currentSpeaker = null;
let nearbyPlayers = [];
let knownPlaces = [];
let activityTimer = null;
let heartbeatTimer = null;

// 日志
function log(level, ...args) {
  const timestamp = new Date().toISOString().slice(11, 19);
  const prefix = `[${timestamp}] [${CONFIG.name}] [${level.toUpperCase()}]`;
  console.log(prefix, ...args);
}

// ============ 连接管理 ============

function connect() {
  return new Promise((resolve, reject) => {
    if (!CONFIG.apiKey) {
      reject(new Error('需要提�?API Key (通过 --apiKey �?AGENT_API_KEY 环境变量)'));
      return;
    }

    log('info', `正在连接�?${CONFIG.serverUrl}...`);

    socket = io(CONFIG.serverUrl, {
      auth: { apiKey: CONFIG.apiKey },
      reconnection: true,
      reconnectionDelay: 1000,
      reconnectionAttempts: Infinity,
    });

    socket.on('connect', () => {
      connected = true;
      log('info', '�?已连�?);
      
      // 初始�?      socket.emit('act:query');
      socket.emit('world:look');
      socket.emit('world:map');
      
      // 启动心跳
      startHeartbeat();
      
      // 启动活动循环
      startActivityLoop();
      
      resolve();
    });

    socket.on('connect_error', (err) => {
      log('error', '连接失败:', err.message);
    });

    socket.on('disconnect', () => {
      connected = false;
      log('warn', '已断开连接，等待重�?..');
      stopHeartbeat();
      stopActivityLoop();
    });

    socket.on('error', (err) => {
      log('error', '错误:', err.message || err);
    });

    // ============ 事件监听 ============

    // 认证成功后获取信�?    socket.on('connect', () => {
      // 等待认证后的事件
    });

    // Act 变化
    socket.on('act:current', (state) => {
      currentAct = state.currentAct || 0;
      currentSpeaker = state.currentSpeaker || null;
      log('info', `当前 Act ${currentAct}`);
      handleActChange(currentAct);
    });

    socket.on('act:changed', (state) => {
      currentAct = state.act || 0;
      log('info', `🎬 Act 变更�?${currentAct}`);
      handleActChange(currentAct);
    });

    socket.on('act:speakerNext', (data) => {
      currentSpeaker = data.speaker;
      log('info', `🎤 下一个发言�? ${currentSpeaker}`);
      if (currentSpeaker === myInfo.id || currentSpeaker === myInfo.name) {
        handleMyTurn();
      }
    });

    // 世界感知
    socket.on('world:lookResult', (result) => {
      myInfo = {
        id: result.player.id,
        name: result.player.name,
        x: result.player.x,
        y: result.player.y,
        zone: result.player.zone,
      };
      nearbyPlayers = result.nearby || [];
      log('debug', `位置: (${myInfo.x}, ${myInfo.y}) @ ${myInfo.zone}`);
      log('debug', `附近 ${nearbyPlayers.length} 人`);
    });

    socket.on('world:mapResult', (places) => {
      knownPlaces = places || [];
      log('debug', `已知 ${knownPlaces.length} 个地点`);
    });

    socket.on('world:moveResult', (result) => {
      if (result.error) {
        log('warn', `移动失败: ${result.error}`);
      } else {
        myInfo.x = result.player.x;
        myInfo.y = result.player.y;
        myInfo.zone = result.targetZone;
        log('info', `移动�?${myInfo.zone} (${myInfo.x}, ${myInfo.y})`);
      }
    });

    socket.on('world:chatResult', () => {
      log('debug', '说话成功');
    });

    // 消息接收
    socket.on('msg:broadcasted', (data) => {
      log('chat', `[广播] ${data.fromName}: ${data.text}`);
      // 可以根据消息内容做出反应
      handleBroadcast(data);
    });

    socket.on('msg:talked', (data) => {
      log('chat', `[私聊] ${data.fromName}: ${data.text}`);
      handlePrivateMessage(data);
    });

    socket.on('msg:roomed', (data) => {
      log('chat', `[队内] ${data.fromName}: ${data.text}`);
    });

    // 玩家状�?    socket.on('player:status', (data) => {
      const status = data.status === 'online' ? '上线' : '下线';
      log('info', `👋 ${data.agentId} ${status}`);
    });

    setTimeout(() => {
      if (!connected) {
        reject(new Error('连接超时'));
      }
    }, 10000);
  });
}

// ============ 心跳管理 ============

function startHeartbeat() {
  if (heartbeatTimer) clearInterval(heartbeatTimer);
  
  heartbeatTimer = setInterval(() => {
    if (!connected) return;
    
    // 发�?look 作为心跳，同时获取最新状�?    socket.emit('world:look');
    log('debug', '💓 心跳');
  }, CONFIG.heartbeatInterval);
  
  log('debug', '心跳已启�?);
}

function stopHeartbeat() {
  if (heartbeatTimer) {
    clearInterval(heartbeatTimer);
    heartbeatTimer = null;
  }
}

// ============ 活动循环 ============

function startActivityLoop() {
  if (activityTimer) clearInterval(activityTimer);
  
  activityTimer = setInterval(() => {
    if (!connected) return;
    
    performRandomActivity();
  }, CONFIG.activityInterval);
  
  log('debug', '活动循环已启�?);
}

function stopActivityLoop() {
  if (activityTimer) {
    clearInterval(activityTimer);
    activityTimer = null;
  }
}

// ============ 自主行为 ============

/**
 * 根据当前 Act 执行相应行为
 */
function handleActChange(act) {
  switch (act) {
    case 1: // 自我介绍
      setTimeout(() => {
        broadcast(`大家好，我是 ${myInfo.name}，很高兴认识大家！`);
      }, 2000 + Math.random() * 5000);
      break;
      
    case 2: // 组队偏好
      setTimeout(() => {
        broadcast('我在寻找队友，有兴趣一起合作吗�?);
      }, 2000 + Math.random() * 5000);
      break;
      
    case 3: // 分组
      socket.emit('world:look');
      break;
      
    case 4: // 产品讨论
    case 5: // 产品打磨
      // 定期更新进度
      break;
      
    case 6: // 人类代言
      break;
      
    case 7: // AI 评审
      break;
      
    case 8: // 颁奖
      break;
      
    case 9: // 共创画布
      // 可以在画布上绘制
      break;
      
    case 10: // 闭幕
      broadcast('感谢大家，这次活动很棒！');
      break;
  }
}

/**
 * 轮到我发言
 */
function handleMyTurn() {
  log('info', '🎤 轮到我发言了！');
  
  // 根据当前 Act 决定说什�?  const speeches = getSpeechesForAct(currentAct);
  const speech = speeches[Math.floor(Math.random() * speeches.length)];
  
  setTimeout(() => {
    broadcast(speech);
  }, 1000 + Math.random() * 3000);
}

function getSpeechesForAct(act) {
  const speeches = {
    1: [
      '大家好，我是新来的，请多多关照！',
      '很高兴认识大家，期待一起合作！',
      '大家好，希望能在这次活动中有所收获�?,
    ],
    2: [
      '我希望能找到志同道合的队友！',
      '我的技能是后端开发，有前端的同学想组队吗�?,
      '我对 AI 方向很感兴趣，有人想一起做相关项目吗？',
    ],
    4: [
      '我觉得我们可以从用户痛点出发考虑�?,
      '我们的产品核心价值是什么？',
      '有没有考虑�?MVP 的范围？',
    ],
    5: [
      '我来整理一下我们讨论的要点�?,
      '这个功能点可以再细化一下�?,
      '我来更新一下产品文档�?,
    ],
    7: [
      '这个产品很有创意�?,
      '我认为这个解决方案很实用�?,
      '团队协作做得很好�?,
    ],
  };
  
  return speeches[act] || ['好的，我明白了�?];
}

/**
 * 处理广播消息
 */
function handleBroadcast(data) {
  // 检查是否被提及
  if (data.text.includes(myInfo.name) || data.text.includes(`@${myInfo.name}`)) {
    log('info', `被提及了！`);
    // 可以选择回复
    if (Math.random() < 0.5) {
      setTimeout(() => {
        const replies = [
          '收到�?,
          '好的，没问题�?,
          '我在这里�?,
          '什么情况？',
        ];
        broadcast(replies[Math.floor(Math.random() * replies.length)]);
      }, 1000 + Math.random() * 2000);
    }
  }
}

/**
 * 处理私聊
 */
function handlePrivateMessage(data) {
  log('info', `收到 ${data.fromName} 的私�? ${data.text}`);
  
  // 自动回复
  setTimeout(() => {
    talk(data.fromId, '收到你的消息了！');
  }, 1000 + Math.random() * 2000);
}

/**
 * 执行随机活动
 */
function performRandomActivity() {
  const rand = Math.random();
  
  if (rand < CONFIG.chatProbability) {
    randomChat();
  } else if (rand < CONFIG.chatProbability + CONFIG.moveProbability) {
    randomMove();
  } else {
    // 更新位置信息
    socket.emit('world:look');
  }
}

/**
 * 随机聊天
 */
function randomChat() {
  const messages = [
    '天气不错�?,
    '有人在吗�?,
    '今天进展如何�?,
    '需要帮忙吗�?,
    '休息一下~',
    '继续加油�?,
  ];
  
  if (nearbyPlayers.length > 0 && Math.random() < 0.5) {
    // 和附近的人说�?    const target = nearbyPlayers[Math.floor(Math.random() * nearbyPlayers.length)];
    chat(`�?${target.name}，你好！`);
  } else {
    // 自言自语
    chat(messages[Math.floor(Math.random() * messages.length)]);
  }
}

/**
 * 随机移动
 */
function randomMove() {
  if (knownPlaces.length === 0) {
    // 随机方向移动
    const dx = Math.floor(Math.random() * 20) - 10;
    const dy = Math.floor(Math.random() * 20) - 10;
    const newX = myInfo.x + dx;
    const newY = myInfo.y + dy;
    log('debug', `随机移动�?(${newX}, ${newY})`);
    socket.emit('world:move', { x: newX, y: newY });
  } else {
    // 移动到随机地�?    const place = knownPlaces[Math.floor(Math.random() * knownPlaces.length)];
    log('debug', `前往 ${place.name}`);
    socket.emit('world:move', { to: place.id });
  }
}

// ============ 动作封装 ============

function broadcast(text) {
  if (!connected) return;
  log('action', `广播: ${text}`);
  socket.emit('msg:broadcast', { text });
}

function talk(toId, text) {
  if (!connected) return;
  log('action', `私聊 ${toId}: ${text}`);
  socket.emit('msg:talk', { to: toId, text });
}

function chat(text) {
  if (!connected) return;
  log('action', `说话: ${text}`);
  socket.emit('world:chat', { text });
}

function move(x, y) {
  if (!connected) return;
  log('action', `移动�?(${x}, ${y})`);
  socket.emit('world:move', { x, y });
}

function moveTo(placeId) {
  if (!connected) return;
  log('action', `前往 ${placeId}`);
  socket.emit('world:move', { to: placeId });
}

function updateStats(mood, confidence) {
  if (!connected) return;
  log('action', `更新状�? mood=${mood}, confidence=${confidence}`);
  socket.emit('player:updateStats', { mood, confidence });
}

// ============ 主程�?============

async function main() {
  parseArgs();
  
  log('info', '=== Agent 自主运行器启�?===');
  log('info', `名称: ${CONFIG.name}`);
  log('info', `服务�? ${CONFIG.serverUrl}`);
  log('info', `API Key: ${CONFIG.apiKey ? CONFIG.apiKey.slice(0, 12) + '...' : '未设�?}`);
  
  try {
    await connect();
    
    // 保持运行
    process.on('SIGINT', () => {
      log('info', '收到退出信�?..');
      if (socket) socket.disconnect();
      process.exit(0);
    });
    
    process.on('SIGTERM', () => {
      log('info', '收到退出信�?..');
      if (socket) socket.disconnect();
      process.exit(0);
    });
    
  } catch (err) {
    log('error', '启动失败:', err.message);
    process.exit(1);
  }
}

main();
