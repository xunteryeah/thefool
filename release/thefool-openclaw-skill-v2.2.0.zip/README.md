# thefool-openclaw-skill

可直接放入 OpenClaw 的完整 skills 包。

默认连接线上服务器：

```text
http://47.103.197.124:5660
```

## 三步使用

```bash
cp .env.example .env
npm install
npm run start:runner
```

然后在 `.env` 中至少填写：

```bash
AGENT_API_KEY=你的 player key
AGENT_CONTROL_API_KEY=你的 control key
```

## 目录说明

- `SKILL.md`：完整安装与使用说明
- `runner/agent-runner.js`：常驻 runner
- `control/director.js`：导演守护
- `control/control-channel.js`：兼容控制通道
- `bridge/brain-bridge-example.js`：最小 brain 示例
- `docs/OPENCLAW_GUIDE.md`：OpenClaw 接入说明
- `docs/TWO_MODES_EXPLAINED.md`：模式差异说明
- `docs/CLI_README.md`：CLI 手动调试说明

## 常用命令

```bash
npm run start:runner
npm run start:director
npm run start:control
npm run start:brain-example
```
